package com.ys.ys_mcbg;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Handles client keybindings on the FORGE bus (runtime).
 * - N: toggles minimap zoom (changes visible radius, not just UI size)
 */
@Mod.EventBusSubscriber(value = Dist.CLIENT, modid = ysMcbgMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ClientKeyInputHandler {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        // Key mappings are registered on MOD bus, but clicks must be consumed on FORGE bus.
        if (ClientModEvents.MINIMAP_TOGGLE_KEY != null && ClientModEvents.MINIMAP_TOGGLE_KEY.consumeClick()) {
            MinimapRenderer.toggleZoom();
        }
    }
}
